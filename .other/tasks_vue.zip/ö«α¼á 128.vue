﻿<template>
<div>

<pre>Формирование ф.128 (в т.ч. для ПТК) с учетом кредитов с плавающей ставкой,
а также формирование реестра кредитов</pre>

  <datepicker label="Отчет за" type="month" name="dateRep" :value="moment().format('YYYY-MM')"></datepicker> 

  <select-dep/>

</div>
</template>


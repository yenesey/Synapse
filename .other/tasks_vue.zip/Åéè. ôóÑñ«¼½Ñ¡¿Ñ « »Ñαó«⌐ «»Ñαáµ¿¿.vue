﻿<template>
<div>

<pre>Уведомление о первой операции по счету клиента на сумму более 600000 руб</pre>

  <select-dep/>

</div>
</template>

﻿<template>
<div>

<pre>Запись файлов на CD</pre>

  <v-text-field label="Метка диска" type="text" name="label" style="width:260px;display:inline-block;" hide-details/>
  <br> <br>
  <input type="file" name="filename" multiple/> 

</div>
</template>

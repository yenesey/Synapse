﻿<template>
<div>

<pre>Сведения об открытых/закрытых счетах, по которым 
не отправлены данные в ФНС по Положению 562-П</pre>

  <datepicker label="Период с" name="dateRep" :value="moment().add(-5, 'day').format('YYYY-MM-DD')"></datepicker> 
  
  <select-dep/>

</div>
</template>

﻿<template>
<div>

<pre>Выгрузка протокола ЗОД за указанную дату</pre>

  <datepicker name="dateRep" :value="moment().add(-1, 'day').format('YYYY-MM-DD')"></datepicker>

  <select-dep/>

</div>
</template>

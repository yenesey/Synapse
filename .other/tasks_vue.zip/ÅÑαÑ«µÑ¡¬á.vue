﻿<template>
<div>

<pre>Формирование документов по переоценке за указанную дату:
  - Распоряжение на переоценку
  - Реестр переоценки</pre>

  <datepicker label="Дата отчета" name="dateRep" :value="moment().add(-2, 'day').format('YYYY-MM-DD')"></datepicker>

  <select-dep/>
  <br>
  <label for="glavBuh"><i>Подписант Распоряжения:</i></label>
  <dlookup 
    name="glavBuh" 
    table="IBS.VW_CRIT_USER" 
    look-in="C_1%" 
    fields="C_1,C_3,C_5" 
    result="ID" 
    style="width:300px" 
		:get-label="getLabel"
    save
  >
	 <!--переопределяем внешний вид выпадающего списка: -->
    <span slot-scope="{item, index}">
     {{item.C_1 + " - " + item.C_5}}<br>
    	<i>[</i> 	
    	<i style="font-weight:bold;color:teal">{{item.C_3}}</i>
     	<i>]</i>  
    </span>
  </dlookup>

</div>
</template>

<script>
export default {
	methods: {
		getLabel : function(item){
			return item.C_1 
		}
	}
}
</script>

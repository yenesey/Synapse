var config = module.exports;

config["node"] = {
    rootPath: "../",
    environment: "node",
    tests: [
        "test/**/*-test.js"
    ]
};

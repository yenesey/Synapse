﻿<template>
<div>
	<label for="group">Рабочая группа</label>
	<select v-model="group_id" id="group">
		<option v-bind:value="-1">-ВСЕ-</option>
	  <option v-for="(gp, index) in groups" v-bind:value="gp.id">{{ gp.name }}</option>
	</select>
	&nbsp;	&nbsp;	&nbsp;
	<label for="unfold">Развернутый вид</label> <input type="checkbox" id="unfold" v-model="unfold">

	<br>
	<div style="width:100%;height:2px;background:linear-gradient(to left, #CBE1F5, #74afd2); margin-top:1em; margin-bottom:1em; clear:both"></div>

	<!------------------------------------------------------------>


	<table class="synapse" v-if="group_id != null" width="100%"> <!--  -->
		<thead>
			<tr>
				<th style="width:60%;">Задача</th>
				<th width="25">Дата нач.</th>
				<th width="25">Дата кон.</th> 
				<th style="width:25px;">Период</th> 
				<th style="width:25px;">Группа</th> 
				<th style="width:25px;">Назначено</th> 
				<th width="6px" >@</th> 
			</tr>
		</thead>
		
		<tbody>
			<tr :class="{selected:activeRow==-1}"
					@click="activeRow = -1"
			> 
				<td colspan=7> 
					<input type="text" style="font-weight: bold; font-style: italic" @keydown.prevent.stop="rowEvent($event.key, -1, null)" ref="base" readonly>
				</td>
			</tr>


			<tr v-for="(el, index) in dataTable"   
				:class="{selected: index==activeRow}"
				@keydown.prevent.stop="rowEvent($event.key, index, table[index])" 
				@click="rowEvent(null, index, table[index])"
			> 
				<td> 
					<div :style="{'padding-left': (unfold? 15*(table[index].level-1):0) + 'px'}" > 
						<input :style="{'font-weight':el.parent_id?'normal':'bold'}" type="text" v-model="el.name" :id="'r'+index+'c0'">
					</div>

				</td>
				<td> 
						<datepicker v-model="el.date1" :id="'r'+index+'c1'" format='yy-mm-dd'></datepicker>
				</td>
				<td> 
						<datepicker v-model="el.date2" :id="'r'+index+'c2'" format='yy-mm-dd'></datepicker> 
				</td>
				<td> 
						<select v-model="el.period_id" :id="'r'+index+'c3'">
						  <option :value="0">-нет-</option> 
						  <option :value="1">До начала</option> 
						  <option :value="2">До окончания</option> 
						  <option :value="3">Каждый день</option> 
						  <option :value="4">Еженедельно</option> 
						  <option :value="5">Ежемесячно</option> 
						  <option :value="6">Ежеквартально</option> 
						  <option :value="7">Ежегодно</option> 
						</select>
				</td>

				<td> 
					<select v-model="el.group_id" :id="'r'+index+'c5'">
					  <option v-for="gp in groups" :value="gp.id">{{ gp.name }}</option>
					</select>
				</td>

				<td> 
					<select v-model="el.assignee_id" :id="'r'+index+'c4'">
					  <option value=-1>-нет-</option> 
					  <option v-for="m in groupMembers(el.group_id)" :value="m.id">{{ m.name }}</option>
					</select>
				</td>
				<td  style="text-align: center;"> 
					<img v-if="table[index].state==1" src="../images/ui-anim_basic_16x16.gif" style="vertical-align: text-bottom;">
				</td>
			</tr>
		</tbody> 
	</table>
</div>
</template>
<script>

var _ = require('lib');

/*----------TreeNode management-------------------------*/
function TreeNode(data){
	this.data = data || null;
	this.level = 0;
	this.parent = null;
	this.state = 0;	
	this.children = [];
}

TreeNode.prototype.find = function(cb){ 
	if ( cb(this) ) return this;
	for (var i=0; i<this.children.length; i++){
		var found = this.children[i].find(cb);
		if (found) return found;
	}
	return null
}

TreeNode.prototype.insert = function(node, cb){
	var root = this.find( cb ) || this;
	root.children.push(node);
	node.parent = root;
	node.level = root.level + 1;
}

TreeNode.prototype.remove = function(node){
	var parent = node.parent;
	var index = parent.children.indexOf(node);
	if (index!==-1){
		parent.children.splice(index,1);
		return true
	}
	return false;
}

TreeNode.prototype.list = function(){
	return [this].concat(this.children.reduce(function(all, el){
		return all.concat(el.list())
	},[]))
}

/*----------TreeNode management END------------*/

var _before = null;

module.exports = {
	props : ['id'],
	data : function(){
		return {
			activeRow : null,
			activeInput : null,

			root : new TreeNode({id:null, parent_id:null}),
			node : null,
			task : {name:'', description:''},

			unfold : false,
			groups : [],
			group_id: null,
		}
	},

	watch : {
		group_id : function(newVal){
			var self = this;

			self.root = new TreeNode({id:null, parent_id:null});

			_.pxhr({ method:'get', url:'/todos?id='+self.id+ (newVal!==-1?'&group='+newVal:'') }) //грузим данные
			.then(function(res){
				res = _.table.restore(res);
				for (var i=0; i<res.length; i++){
					var node = new TreeNode(res[i]);
					self.root.insert(node, function(n){ return n.data && n.data.id === node.data.parent_id } )	
				}
				self.node = self.root;
				self.$refs.base.value = self.chain(self.node);
			})
		}
	},

	computed : {
		table : function(){
			if (this.node === null) return [];
			if (this.unfold)
				return this.node.list().splice(1);
			else
				return this.node.children
		},
		dataTable	: function(){
			return this.table.map(function(el) {return el.data })
		}

	},

	mounted : function(){ //при появлении в DOM
		var self = this;

		self.$watch('task', self.changes, {deep:true});

		_.pxhr({ method:'get', url:'/access/map?class=groups' }) //грузим рабочие группы
		.then(function(res){
			self.groups = _.table.restore(res.access)
				.filter(function(el){ return el.granted })
		
			self.groups.forEach(function(el){
				_.pxhr({ method:'get', url:'/access/members?object=' + el.id })
				.then(function(res){ el.members =  _.table.restore(res) })

			})

		})
	},

	methods : {
		trunc: function (s, l){
			return (s.length > l) ? (s.substr(0, l) + '..')	: s
		},
		chain: function(node){
			return node ? this.chain(node.parent) +  (node.data.name ? ( '[ ' + this.trunc(node.data.name, 30) ) + ' ] ':'')  : '' 
		},
		groupMembers : function(id){
			var find = this.groups.find(function(gp){return gp.id === id});
			if (find) return find.members;
			return null;
		},
		
		debounced : _.debounceKeyed(function(first, last){
			var self = this;
			var changes = {};
			if (last.task != -1)	changes = _.difference(first, last);
			var node = this.root.find(function(n){ return n.data && n.data.id === last.id});

			if (!node) return; 
			if (!changes) {
				node.state = 0;
				return; 
			}
			if ('error' in changes) delete changes.error;
		
			if (Object.keys(changes).length===0) return;
			if (last.id) changes.id = last.id;


			_.pxhr({ method:'put', url:'/todos?id='+self.id, data : changes })
			.then(function(res){
					node.state = 0;
					_before = _.clone(last);
				})
			},3000
		),

		changes : function(obj){
			this.root.find(function(n){ return n.data && n.data.id === obj.id}).state = 1;
			this.debounced(obj.id || -1, [0,1], _before, obj);
		},


		rowEvent: function(key, index, node){
			var id = document.activeElement.id;
			if (id){
				/r(\d+)c(\d+)/.test(id);
				this.activeInput = RegExp.$2;
			}

			switch (key) {
				case null:
					this.activeRow = index || 0;
				break;

				case 'Down':
				case 'ArrowDown':
					if (this.activeRow < this.table.length-1) 
						this.activeRow++
				break;

				case 'ArrowUp':
				case 'Up':
					if (this.activeRow > -1) 
						this.activeRow--
				break;

				case 'Enter':
					if ((this.activeRow === -1) || (node===null)) node = this.node.parent || this.node; //go UP
					this.node = node;
					this.$refs.base.value = this.chain(this.node);
					this.activeRow = -1;
					this.$refs.base.focus();
				break;

				case 'Insert':
				case 'Ins':
					var self = this;
					var parent_id = self.node.data.id;
					_.pxhr({ method:'put', url:'/todos?id='+self.id, data : {parent_id : parent_id, group_id : self.group_id } })
					.then(function(res){
						if (res.id)
							self.root.insert(new TreeNode(res), function(n){ return n.data && n.data.id === parent_id } )	
					})
				break;

				case 'Delete':
				case 'Del':
					var self = this;
					_.pxhr({ method:'delete', url:'/todos?id='+self.id, data : {id : node.data.id	} })
					.then(function(res){
						if (res.result){
							self.root.remove(node);
						}
					})


				break;
			}
			var el = document.getElementById('r'+this.activeRow+'c'+this.activeInput);
			if (el) el.focus();

			if (this.dataTable.length){
				var task = this.dataTable[this.activeRow !==-1 ? this.activeRow : 0]; 
				if (task != this.task){
					this.task = this.dataTable[this.activeRow !==-1 ? this.activeRow : 0]; 
					_before = _.clone(this.task);				
				}
			} else
				task = {name:'', description:''};

		}
	}
}
</script>


﻿<template>
<div>
	<tabs>
		<tab header="Ввод и редактирование">
			<todos-edit :id="id"></todos-edit>
		</tab>

		<tab header="Исполнение и контроль">
			<test></test>
		</tab>

	</tabs>
</div>
</template>

<script>
var _ = require('lib');
var Vue = require('vue');
Vue.component('todos-edit', require('./todos-edit.vue'));
Vue.component('test', require('./test.vue'));


module.exports = {
	props : ['id']

}

</script>


<style>
</style>



﻿<template>
<div>
	<table class="synapse"  width="100%">
		<thead>
			<tr>
				<th style="width:60%;">Item</th>
				<th width="25">Date1</th>
				<th width="25">Date2</th> 
			</tr>
		</thead>
		
		<tbody>

			<tr v-for="(el, index) in dataTable"   
				:class="{selected: index==activeRow}"
				@keydown.prevent.stop="rowEvent($event.key, index, dataTable[index])" 
				@click="rowEvent(null, index, dataTable[index])"
			> 
				<td> 
					<input :style="{'font-weight':el.parent_id?'normal':'bold'}" type="text" v-model="el.name" :id="'r'+index+'c0'">
				</td>
				<td> 
						<input v-model="el.date1" :id="'r'+index+'c1'" type="text"></input>
				</td>
				<td> 
						<input v-model="el.date2" :id="'r'+index+'c2'" type="text"></input>
				</td>
			</tr>
		</tbody> 
	</table>
</div>
</template>
<script>

var _before = null;

module.exports = {
	props : ['id'],
	data : function(){
		return {
			activeRow : null,
			dataTable : [],
		}
	},

	
	mounted : function(){ //при появлении в DOM
		
		for (var i = 0; i< 300 ; i++)
				this.dataTable.push({
					id : i,
					name : 'element #' + i,
					date1 : '2017-01-01',
					date2 : '2017-01-01',
				})	

	},

	methods : {
		rowEvent: function(key, index, node){

			switch (key) {
				case null:
					this.activeRow = index || 0;
				break;

				case 'Down':
				case 'ArrowDown':
					if (this.activeRow < this.dataTable.length-1) 
						this.activeRow++
				break;

				case 'ArrowUp':
				case 'Up':
					if (this.activeRow > -1) 
						this.activeRow--
				break;
			}
		
		}
	}
}
</script>

